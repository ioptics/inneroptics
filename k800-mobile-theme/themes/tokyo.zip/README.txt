Tokyo Version 1.00

To use, just extract the .thm file and upload to your phones 'themes' directory. Select the theme in the phone
and you're good to go.

Changelog:

1.0:  Initial Release


www.inneroptics.com, www.inneroptics.com/k800-mobile-theme

Themes developed in Sony Ericsson Themes Creator Version 3.10, Copyright (C) Sony Ericsson Mobile Communications AB.