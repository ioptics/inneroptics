Orb Version 1.01

To use, just extract the .thm file and upload to your phones 'themes' directory. Select the theme in the phone and you're good to go.

Changelog:

1.01: Changed text colours to ensure no white text was displayed on white backgrounds, thanks to James for spotting this.

1.0:  Initial Release


www.inneroptics.com, www.inneroptics.com/k800-mobile-theme

Themes developed in Sony Ericsson Themes Creator Version 2.53, Copyright (C) Sony Ericsson Mobile Communications AB.