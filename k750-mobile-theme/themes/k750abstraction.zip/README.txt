K750 Abstraction Version 1.0

To use, just extract the .thm file and upload to your phones 'themes' directory. Select the theme in the phone
and you're good to go.

Changelog:

1.0:  Initial Release


www.inneroptics.com, www.inneroptics.com/k750-mobile-theme

Background image is based off a purchased iStock image.

Themes developed in Sony Ericsson Themes Creator Version 2.53, Copyright (C) Sony Ericsson Mobile Communications AB.